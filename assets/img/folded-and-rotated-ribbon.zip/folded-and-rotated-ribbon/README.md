# Folded and rotated ribbon

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/dyZOBex](https://codepen.io/t_afif/pen/dyZOBex).

Related article: https://www.freecodecamp.org/news/make-a-css-only-ribbon/